#include "stdafx.h"

#include <stdio.h>
#include <windows.h>
#include <process.h>	// process API for shutdown / reboot

#include <shobjidl.h>	// Shell Link Interface
#include <shlguid.h>

#include <string>		// some STL classes
#include <deque>
#include <algorithm>
#include <iostream>
#include <strstream>

#define MAX_CLASS_NAME_LEN 32 // Stolen from <cfgmgr32.h>

#define error(param){\
std::strstream os;\
os << param << (char)0x00;\
MessageBox(NULL, os.str(), "InstallDriver - Error", MB_OK|\
  MB_ICONERROR|MB_APPLMODAL);\
}

#ifdef _DEBUG

#define warning(param){\
std::strstream os;\
os << param << (char)0x00;\
MessageBox(NULL, os.str(), "InstallDriver - Warning", MB_OK|\
  MB_ICONWARNING|MB_APPLMODAL);\
}

#define info(param){\
std::strstream os;\
os << param << (char)0x00;\
MessageBox(NULL, os.str(), "InstallDriver - Information", MB_OK|\
  MB_ICONINFORMATION|MB_APPLMODAL);\
}
#else
//#define error(param)
#define warning(param)
#define info(param)
#endif

BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{
    switch (ul_reason_for_call)
	{
		case DLL_PROCESS_ATTACH:
		case DLL_THREAD_ATTACH:
		case DLL_THREAD_DETACH:
		case DLL_PROCESS_DETACH:
			break;
    }
    return TRUE;
}

int DisplayError(TCHAR * ErrorName)
{
    DWORD Err = GetLastError();
    LPVOID lpMessageBuffer = NULL;
    
    if (FormatMessage( 
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
        NULL, 
        Err,  
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &lpMessageBuffer,  
        0,  
        NULL )) {
        error(ErrorName << " FAILURE: " << (TCHAR *)lpMessageBuffer << "\n");
    }
    else {
        error(ErrorName << " FAILURE: (" << Err << ")\n");
    }
    
    if (lpMessageBuffer) LocalFree( lpMessageBuffer ); // Free system buffer 
    
    SetLastError(Err);
    return FALSE;
}

HRESULT CreateLink(LPCSTR lpszPathObj, LPCSTR lpszPathLink, LPCSTR lpszIconPath, LPCSTR lpszWorkDir) 
{ 
    HRESULT hres; 
    IShellLink* psl; 
 
	CoInitialize(NULL);

    // Get a pointer to the IShellLink interface. 
    hres = CoCreateInstance(CLSID_ShellLink, NULL, CLSCTX_INPROC_SERVER, 
                            IID_IShellLink, (LPVOID*)&psl); 
    if (SUCCEEDED(hres)) 
    { 
        IPersistFile* ppf; 
 
        // Set the path to the shortcut target and add the description. 
        psl->SetPath(lpszPathObj); 
		psl->SetIconLocation(lpszIconPath,0);
        //psl->SetDescription(lpszDesc); 
		psl->SetWorkingDirectory(lpszWorkDir);
 
        // Query IShellLink for the IPersistFile interface for saving the 
        // shortcut in persistent storage. 
        hres = psl->QueryInterface(IID_IPersistFile, (LPVOID*)&ppf); 
 
        if (SUCCEEDED(hres)) 
        { 
            WCHAR wsz[MAX_PATH]; 
 
            // Ensure that the string is Unicode. 
            MultiByteToWideChar(CP_ACP, 0, lpszPathLink, -1, wsz, MAX_PATH); 
			
            // TODO: Check return value from MultiByteWideChar to ensure 
                     //success.
 
            // Save the link by calling IPersistFile::Save. 
            hres = ppf->Save(wsz, TRUE); 
            ppf->Release(); 
        } 
        psl->Release(); 
    } 

	CoUninitialize();
	return hres; 
}

HRESULT RemoveLink(LPCSTR lpszLinkFile/*, LPCSTR lpszPathLink, LPCSTR lpszIconPath, LPCSTR lpszDesc*/)
{
	remove(lpszLinkFile);
	return 0;
}

std::string getAParam(std::string::iterator& iter, std::string::iterator end)
{
  std::string p;
  char c;
  bool isQuoted = false;
  while( iter != end ) {
    c = *iter++;
    if (c == '"') {
      // Toggle Qouted flag
      isQuoted = isQuoted ? false : true;
      continue;
    }
    if ((c == ' ') && !isQuoted && p.size()) {
      // param extracted
      break;
    }
    p += c;
  }
  return p;
}

void getParameter( std::deque<std::string>& params, const char* cmdLine )
{
  std::string line(cmdLine);
  std::string::iterator iter = line.begin();
  std::string param;
  while(iter != line.end()) {
    param = getAParam(iter, line.end());
    if (param.size()) {
      params.push_back(param);
    }
  }
}

extern "C"
int APIENTRY WinMain( HINSTANCE instance, HINSTANCE prevInstance,
		      LPSTR  cmdParam, int cmdShow )
{
  char* iargv[3] = {"InstallDriver.exe",0, 0};
  std::deque<std::string> params;
  int result = -1;

  info("got cmdline '" << (char*)cmdParam << "'.");

  getParameter(params, (char*)cmdParam);

  if ( params.size() >= 1 )
  {
	if( params[0]=="-reg" )
	{
		if ( params.size() != 2 ) {
			error("Wrong number of parameters (" << params.size() << "). Expected 2 in " <<
			"command line '" << (char*)cmdParam << "'.");
			return -1; // wrong number of parameters
		}
		char *sysvar,command[2048];
		sysvar = getenv( "SystemRoot" );
		sprintf(command,"%s\\regedit.exe",sysvar);

		result = spawnl(_P_DETACH,command,command,"/s",params[1].c_str(),NULL);
	}
	else if( params[0]=="-reboot" )
	{
		if ( params.size() != 2 ) {
			error("Wrong number of parameters (" << params.size() << "). Expected 2 in " <<
			"command line '" << (char*)cmdParam << "'.");
			return -1; // wrong number of parameters
		}
		char *sysvar,command[2048];
		sysvar = getenv( "SystemRoot" );
		sprintf(command,"%s\\system32\\shutdown.exe",sysvar);

		spawnl(_P_DETACH,command,command,
			"-r","-c","\"The system will reboot within the next few seconds\"",
			"-t",params[1].c_str(),NULL);
		result = 0;
	}
	else if( params[0]=="-shutdown" )
	{
		if ( params.size() != 2 ) {
			error("Wrong number of parameters (" << params.size() << "). Expected 2 in " <<
			"command line '" << (char*)cmdParam << "'.");
			return -1; // wrong number of parameters
		}
		char *sysvar,command[2048];
		sysvar = getenv( "SystemRoot" );
		sprintf(command,"%s\\system32\\shutdown.exe",sysvar);

		spawnl(_P_DETACH,command,command,
			"-s","-c","\"The system will shutdown within the next few seconds\"",
			"-t",params[1].c_str(),NULL);
		result = 0;
	}
	else if( params[0]=="-createLink" )
	{
		if ( params.size() != 5 ) {
			error("Wrong number of parameters (" << params.size() << "). Expected 2 in " <<
			"command line '" << (char*)cmdParam << "'.");
			return -1; // wrong number of parameters
		}
		result = CreateLink(params[1].c_str(),params[2].c_str(),params[3].c_str(),params[4].c_str());
	}
	else if( params[0]=="-removeLink" )
	{
		if ( params.size() != 2 ) {
			error("Wrong number of parameters (" << params.size() << "). Expected 2 in " <<
			"command line '" << (char*)cmdParam << "'.");
			return -1; // wrong number of parameters
		}
		result = RemoveLink(params[1].c_str());
	}
	else
	{
		error("wrong command: " << params[0] );
	}
  }
  else
  {
	error("usage: InstallDriver [\n" 
		<< " -reg        <full Path to import REG file>\n"
		<< " -createLink <target> <linkfile> <iconfile> <path>\n"
		<< " -removeLink <linkfile>\n"
		<< " -reboot     <time>\n"
		<< " -shutdown   <time>");
  }

  return result;
}
