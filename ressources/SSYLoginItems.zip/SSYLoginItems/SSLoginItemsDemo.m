//#import <Foundation/Foundation.h>
//#import <CoreServices/CoreServices.h>
#import "SSYLoginItems.h"

NSString* const kSafariPath = @"/Applications/Safari.app" ;

void TestIsLoginItem(
					 NSString* path,
					 BOOL doLog,
					 BOOL* isLoginItem_p,
					 BOOL* isHidden_p) {
	NSNumber* loginItem = nil ;
	NSNumber* hidden = nil ;
	NSError* error = nil ;
	BOOL ok = [SSYLoginItems isURL:[NSURL fileURLWithPath:path]
						 loginItem:&loginItem
							hidden:&hidden
							 error:&error] ;
	if (!ok) {
		NSLog([error description]) ;
	}
	
	if (doLog) {
		NSLog(@"isLoginItem=%@ hidden=%@ for %@", loginItem, hidden, path) ;
	}
	
	if (isLoginItem_p != NULL) {
		*isLoginItem_p = [loginItem boolValue] ;
	}
	
	if (isHidden_p != NULL) {
		*isHidden_p = [hidden boolValue] ;
	}
}	


void TestIsSafariLoginItem(BOOL expectedIsLoginItem, BOOL expectedHidden) {
	BOOL actualIsLoginItem ;
	BOOL actualIsHidden ;
	TestIsLoginItem(
					kSafariPath,
					NO,
					&actualIsLoginItem,
					&actualIsHidden
					) ;
	if ((expectedIsLoginItem == actualIsLoginItem) && (expectedHidden == actualIsHidden)) {
		NSLog(@"Did read expected result using API:  Safari isLoginItem=%d, isHidden=%d",
			  actualIsLoginItem,
			  actualIsHidden) ;
	}
	else {
		NSLog(@"Did read UNEXPECTED result using API for Safari:\n      isLoginItem: expected:%d, actual:%d\n      isHidden: expected%d, actual:%d",
			  expectedIsLoginItem,
			  actualIsLoginItem,
			  expectedHidden,
			  actualIsHidden) ;
	}
}

void MakeTestSafariLoginItemHidden(NSString* const kAppPath,BOOL hidden) {
	NSLog(@"Will set a Login Item with hidden=%d", hidden) ;
	NSError* error = nil ;
	[SSYLoginItems addLoginURL:[NSURL fileURLWithPath:kAppPath]
					   hidden:[NSNumber numberWithBool:hidden]
						error:&error] ;
	if (error != nil) {
		NSLog([error description]) ;
		goto end ;
	}
end: 
	;
}

void RemoveTestSafariLoginItem(NSString* const kAppPath) {
	NSLog(@"Will remove from Login Items.") ;
	NSError* error = nil ;
	[SSYLoginItems removeLoginURL:[NSURL fileURLWithPath:kAppPath]
						   error:&error] ;
	if (error != nil) {
		NSLog([error description]) ;
		goto end ;
	}
end:
	;
}

int main (int argc, const char * argv[]) {
	NSAutoreleasePool * pool = [[NSAutoreleasePool alloc] init];

	if( argc<=1 )
	{
		NSLog(@"usage: SSLoginItems { -createLink | removeLink } <targetpath>");
		exit(-1);
	}

	// Make Safari a login item, not hidden
	NSString* const path = [NSString stringWithFormat:@"%s",argv[2]];

	if( strcmp(argv[1],"-createLink")==0 )
		MakeTestSafariLoginItemHidden(path,NO) ;
	
	// Remove Safari from login items
	if( strcmp(argv[1],"-removeLink")==0 )
		RemoveTestSafariLoginItem(path) ;

	[pool drain] ;

	return 0 ;
}
