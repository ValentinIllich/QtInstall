#import "NSError+Easy.h"
//#import "NSString+Truncate.h"

NSString* const SSYLocalizedTitleErrorKey = @"LocalizedTitle" ;
NSString* const SSYUnderlyingExceptionErrorKey = @"UnderlyingException" ;

@implementation NSError (Easy) 

+ (NSError*)errorWithLocalizedDetails:(NSString*)localizedDetails
								 code:(int)code
							   sender:(id)sender
							 selector:(SEL)selector {
	if (localizedDetails == nil) {
		localizedDetails = @"unspecified" ;
	}
	if (sender != nil) {
		localizedDetails = [localizedDetails stringByAppendingFormat:@"\n   Object Class: %@",
							NSStringFromClass([sender class])] ;

	}
	if (selector != NULL) {
		localizedDetails = [localizedDetails stringByAppendingFormat:@"\n   Method: %@",
							NSStringFromSelector(selector)] ;
	}
	NSDictionary* userInfo = [NSDictionary dictionaryWithObject:localizedDetails
														 forKey:NSLocalizedDescriptionKey] ;
	NSString* domain = [[NSBundle mainBundle] bundleIdentifier] ;
	return [NSError errorWithDomain:domain
							   code:code
						   userInfo:userInfo] ;
}

+ (NSError*)errorWithHTTPStatusCode:(int)code
							 sender:(id)sender 
						   selector:(SEL)selector {
	NSString* localizedDetails = [NSString stringWithFormat:@"HTTP Status Code: %d %@",
								  code,
								  [NSHTTPURLResponse localizedStringForStatusCode:code]] ;
	return [self errorWithLocalizedDetails:localizedDetails
									  code:code
									sender:sender
								  selector:selector] ;
}

- (NSError*)errorByAddingUserInfoObject:(id)object
								 forKey:(NSString*)key {
	NSMutableDictionary* userInfo = [[self userInfo] mutableCopy] ;
	if (object != nil) {
		if (userInfo) {
			id existingObject = [userInfo objectForKey:key] ;
			if (
				[existingObject isKindOfClass:[NSString class]]
				&& [object isKindOfClass:[NSString class]]) {
				object = [NSString stringWithFormat:@"%@\n\n%@",
									 existingObject, object] ;
			}
		}
		else {
			userInfo = [[NSMutableDictionary alloc] initWithCapacity:1] ;
		}
		[userInfo setObject:object forKey:key] ;
	}
	int code = [self code] ;
	NSString* domain = [self domain] ;
	NSError* newError = [NSError errorWithDomain:domain
											code:code
										userInfo:userInfo] ;
	[userInfo release] ;
	return newError ;
}

- (NSError*)errorByAddingLocalizedDescription:(NSString*)newText {
	return [self errorByAddingUserInfoObject:newText
									  forKey:NSLocalizedDescriptionKey] ;
}

- (NSError*)errorByAddingLocalizedFailureReason:(NSString*)newText {
	return [self errorByAddingUserInfoObject:newText
									  forKey:NSLocalizedFailureReasonErrorKey] ;
}

- (NSError*)errorByAddingLocalizedRecoverySuggestion:(NSString*)newText {
	return [self errorByAddingUserInfoObject:newText
									  forKey:NSLocalizedRecoverySuggestionErrorKey] ;
}

- (NSError*)errorByAddingLocalizedRecoveryOptions:(NSArray*)recoveryOptions {
	return [self errorByAddingUserInfoObject:recoveryOptions
									  forKey:NSLocalizedRecoveryOptionsErrorKey] ;
}

- (NSError*)errorByAddingUnderlyingError:(NSError*)underlyingError {
	return [self errorByAddingUserInfoObject:underlyingError
									  forKey:NSUnderlyingErrorKey] ;
}

- (NSError*)errorByAddingUnderlyingException:(NSException*)exception {
	NSMutableDictionary* additions = [NSMutableDictionary dictionary] ;
	id value ;
	
	value = [exception name] ;
	if (value) {
		[additions setObject:value
					  forKey:@"Name"] ;
	}
	
	value = [exception reason] ;
	if (value) {
		[additions setObject:value
					  forKey:@"Reason"] ;
	}

	value = [exception userInfo] ;
	if (value) {
		[additions setObject:value
					  forKey:@"User Info"] ;
	}
	
	return [self errorByAddingUserInfoObject:additions
									  forKey:SSYUnderlyingExceptionErrorKey] ;
}

- (NSError*)errorByAddingLocalizedTitle:(NSString*)title {
	return [self errorByAddingUserInfoObject:title
									  forKey:SSYLocalizedTitleErrorKey] ;
}

- (NSString*)localizedTitle {
	return [[self userInfo] objectForKey:SSYLocalizedTitleErrorKey] ;
}

- (NSString*)longDescription {
	// Unfortunately, if you carefully read the documentation for NSError you'll see
	// that the NSLocalizedDescriptionKey may or may not be in the userInfo
	// dictionary.  So, in order to present a consistent email content, we first
	// put it into the userInfo dictionary if it is not in there.
	NSDictionary* userInfo = [self userInfo] ;
	if (![userInfo objectForKey:NSLocalizedDescriptionKey]) {
		NSString* localizedDescription = [self localizedDescription] ;
		if (localizedDescription) {
			NSMutableDictionary* userInfoMute = [NSMutableDictionary dictionaryWithDictionary:userInfo] ;
			[userInfoMute setObject:localizedDescription
							 forKey:NSLocalizedDescriptionKey] ;
			userInfo = userInfoMute ;
		}
	}
	
	// The following is to make sure that if something really went haywire and caused
	// the NSError's userInfo dictionary to become very large, we truncate each key and
	// values, and the aggregate description, to a readable length so that the user
	// will not be afraid to send it and the support engineer will not have to eat
	// 5 gallons of popcorn before she has the motivation to read it.
	NSMutableString* truncatedUserInfo = [NSMutableString string] ;
	NSEnumerator* e = [userInfo keyEnumerator] ;
	id key ;
	id value ;
	while (((key = [e nextObject]) != nil) && ([truncatedUserInfo length] < 8192)) {
		value = [userInfo objectForKey:key] ;
		NSString* description = nil ;
		SEL sel = @selector(longDescription) ;
		if ([value respondsToSelector:sel]) {
			description = [value performSelector:sel] ;
		}
		if (!description) {
			description = [value description] ;
		}
		[truncatedUserInfo appendFormat:@"   **Key: %@\n   Value: %@\n",
		 [[key description] stringByTruncatingMiddleToLength:256],
		 [description stringByTruncatingMiddleToLength:1024]] ;
	}
	
	return [NSString stringWithFormat:@"##### NSError %p with Instance Variables #####\n***     code: %d\n***   domain: %@\n*** userInfo:\n%@",
			self,
			[self code],
			[self domain],
			truncatedUserInfo] ;
}

@end